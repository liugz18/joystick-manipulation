Joystick To Servo Platform  Connector
=======
This is a simple program that read the joystick command and then send the command to the servo platform.
### Configuration and Usage 
#### Confugreation
1. Copy the sdl related dlls in the `lib` folder to a folder and then set the environment variables PYSDL2_DLL_PATH to the path of the folder.
2. install PySDL2 by running `pip install pysdl2`
#### Usage
Go to source folder and run
> python joystick_servo_platform.py
